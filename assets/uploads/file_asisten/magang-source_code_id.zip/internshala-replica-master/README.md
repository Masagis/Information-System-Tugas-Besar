# internshala-replica
A replica-version of the website Internshala 

# Features-  

Two types of user: Employee and Student with different functionalities  

-Guest user can view the internship-list  
-Clicking Apply on any internship navigates to login page  
-Sign-up page to register students as well as Employers  


# Student-functions:
-Can view all available internships  
-Can apply to any internship  

# Employer-functions:
-Can add internships with minimal details like Title, Desciption, Stipend, Duration  
-Can view internships posted by them  
-Can view all the applications received for their internship-positions  
