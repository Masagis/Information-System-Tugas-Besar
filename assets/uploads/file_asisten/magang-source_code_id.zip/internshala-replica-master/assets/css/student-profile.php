<html>
  <body>
    <h1>Student profile page</h1>
  </body>
</html>